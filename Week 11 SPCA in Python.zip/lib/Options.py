class Options:
    def __init__(self, threshold_m, threshold_n, max_iteration, tolerance, num_pc):
        self.threshold_m = threshold_m
        self.threshold_n = threshold_n
        self.max_iteration = max_iteration
        self.tolerance = tolerance
        self.num_pc = num_pc